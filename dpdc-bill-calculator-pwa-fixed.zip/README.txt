DPDC Bill Calculator - fixed edition

QUICK START
For a single-file calculator, open dpdc-bill-app-fixed.html from the delivery folder.
For the installable PWA, extract this ZIP and serve this folder over HTTPS or
localhost. With Python installed, run: python -m http.server 8080
Then open http://localhost:8080/index.html and use Install when offered.

SLIPS
Go to Sub-Meters > Slip & message settings, above the tenant readings.
Tick individual fields to show them; untick them to hide them.
Show all information / Hide all information shortcuts are available.
Edit the title/footer, preview a tenant, and select 1-15 slips per A4 page.
Choose Portrait, Landscape, or Automatic - best fit. Automatic considers the
selected information and the most detailed tenant slips when choosing a grid.
The page layout preview shows the chosen orientation, columns and rows.
Your field, density and orientation choices are saved and included in backups.
Print at 100%, A4, 10 mm margins, with browser headers/footers off.
The generated document sets the page orientation to match your selection.
Slips automatically reduce their text size to fit. Fewer slips mean larger text.
Printed slips and slip images honor the selected fields.
Tenant names, readings, rates, dues and phone numbers are edited on each card.

MESSAGES
Enter the tenant's Bangladeshi mobile number on their card.
Click WhatsApp or SMS to open an addressed bill message.
Click Edit message to customize that tenant's message before opening the app.
Click Share slip photo to share a PNG image of that tenant's configured bill.
Choose WhatsApp or another messaging app in the device share menu, then select
the recipient. The browser cannot preselect a recipient for an image attachment.
If file sharing is unavailable, the photo downloads; attach it in the chat.
The photo preview also offers Download photo and Share slip photo actions.
You can also define a shared message template in Slip & message settings.
An empty template uses the visible slip fields. Template fields include:
{building} {month} {name} {phone} {previous} {current} {units} {rate}
{amount} {dues} {total} {dueDate} {note}
Use automatic message clears a tenant's custom override.
Message overrides are cleared when starting the next month.
The messaging app requires its own final Send action. No messages are sent
automatically. SMS requires a phone or a configured messaging application.

DATA
Existing storage and JSON backups from the original app remain readable.
Reducing the meter count hides cards without deleting their readings or drafts.
Increase the count to restore hidden cards. Hidden cards are excluded from bills.
Meter slots have stable identities so renaming or duplicate names do not move
recorded payments to another meter.
Backup restoration commits state/history/language in one storage write.
Back up your old app and import its JSON into this edition if using a different
browser, location, or origin. Browser data does not automatically cross origins.

FIXES
Invalid or decreasing tariff limits are rejected before calculation.
Pull total from Main Meter always recalculates the current inputs.
Suggested rate and reconciliation use the same explicitly entered main bill.
The service worker only handles app assets and its own scoped caches.
Tariff defaults are inherited from the supplied app; they have not been verified
against an official current tariff schedule. Check your official DPDC bill.
