# Tenant bill messaging review

Reviewed 12 November 2026 (Asia/Dhaka).

Direct WhatsApp/SMS actions now appear on each tenant card and individual bill preview. They construct an addressed message at click time, using the current app language, billing data and selected text details. The user reviews and sends it in the external messaging app. No delivery state, payment status or automatic sending is implied. A contact-only dialog saves missing/invalid numbers and continues to the selected channel; finalized financial records stay locked. Copy bill text offers clipboard and selectable-text fallbacks.

## Verification

- 16 isolated messaging browser checks pass: direct named actions, addressed links and encoding, actual newlines, latest calculations, Bangla digits/body, missing/invalid contacts, contact saving after finalization, invalid and over-limit readings, applicable shared-rate errors, independent valid tenants/custom rates, payment/credit labels, document-detail switches, manual-copy fallback, cross-tab protection and EN/BN responsive layouts.
- 41 existing Node calculation/helper/Drive checks pass.
- 20 established app browser checks pass, including previous WhatsApp preview, payment/receipt, preserve-on-add, finalize/reopen/carry, JSON import/export, print/PDF, saved-state conflict protection and cached application assets.
- Direct action targets are 36px minimum on desktop and 44px on phone layouts. Desktop and 320px screenshots were inspected; message actions reflow without clipping. Keyboard names include each flat, and the contact dialog focuses the phone field.
- Independent review identified two defects: direct messaging bypassed applicable HTML range checks, and a delayed clipboard failure could displace a storage-conflict recovery dialog. Both were fixed and their regression cases pass.

## Limits

All messaging tests intercept URLs. No real SMS or WhatsApp message was sent. Physical handset/app handling, SMS body prefilling and actual delivery remain unverified. SMS links use RFC 5724; some handlers, including Apple's documented recipient-only scheme, may omit the body. Copy bill text is available for this case. Long/Bangla bills may use multiple SMS messages; the user's messaging app/operator controls sending and charges. These actions share text; PDF files must be saved and attached separately.

The inspected change scope is tenant messaging and its contact/copy flows, not a new whole-app visual audit. The app retains Guest mode, optional manual Drive backups, existing calculations and hidden rounding on tenant messages/slips.


## Short SMS and independent language update

Added the accepted two follow-up improvements: a fixed compact SMS summary and a separately saved English/Bangla message-language preference. The selector appears in billing, individual bill preview and Settings. English SMS uses Tk and amounts without unnecessary fractional zeros; Bangla uses Bangla numerals. Detailed WhatsApp, copied text and system share retain selected document details. All totals still come from the current bill, and user-provided names/notes remain unchanged.

Final verification: 20 messaging browser checks, 44 calculation/helper/Drive transport tests and 20 established app-browser checks pass. The new checks cover opposite app/message/PDF/numeral settings, unchanged global state after formatting, synchronized controls, copied/system-share body, JSON backup and reload persistence, and one-time initialization of legacy records. Optional messageLanguage accepts en/bn and rejects malformed values; old v3 backups remain accepted. Desktop and 320px language controls were visually inspected. An independent bounded source/VM review found no actionable defect. Real handset/message delivery remains unverified; all outgoing message requests were intercepted in tests.
