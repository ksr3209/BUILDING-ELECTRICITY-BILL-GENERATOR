# Google app-data and Guest mode review

Reviewed 12 November 2026 (Asia/Dhaka).

## Delivered

Optional manual, versioned Google Drive app-data backup/restore, plus explicit Guest mode. Existing monthly billing/printing stays local. Guest selection preserves the ledger, clears the tab connection and pending Drive restore, and remembers the device preference separately from ledger exports. JSON recovery/import and CSV export remain available without Google.

Google uses only drive.appdata through GIS, with a public Web OAuth client ID stored separately and short-lived tokens in memory. A successful upload creates a new file; there is no overwrite/pruning or automatic sync. Restore checks file metadata, size and ledger schema, previews source information, compares local/account revisions, requests a local recovery download, and commits validated replacement only if browser storage accepts it.

## Verification

- 41 Node calculation, helper and Drive transport checks pass.
- 19 isolated Drive/Guest browser checks pass using synthetic Google responses: scope/configuration, manual uploads, no autosave uploads, token storage, failed uploads, cancel/confirm restore, malformed data, changed account/client, stale local preview, failed recovery download, denied/expired consent, cross-tab conflict during delayed read, Guest export/reload/reconnect, English/Bangla 320px reflow and runtime errors.
- 20 established billing-browser checks pass after Guest mode: payment/receipt, reading preservation, carry/finalize/reopen, local import/export, printing, cached app files, concurrent writes, corrupt-data recovery and responsive layouts.
- 15 existing feature-browser checks pass for print selection, carry warnings, unusual readings, account history, backup reminders and Enter navigation. Guest changes subsequently affected connection controls/save-label presentation only; the full billing suite was rerun afterward.
- New runtime scripts and service worker pass syntax checks. Desktop/mobile screenshots were inspected; the Drive card follows the existing Settings layout and all controls reflow at 320px.
- Independent source review caught a delayed-read/cross-tab conflict race. It was fixed by checking storage again before opening a restore preview; its regression scenario passes. No additional actionable source defects were identified in that bounded review.

## Limits

No real OAuth client/account was supplied. Live Google sign-in, API authorization and actual remote round trips are not verified. Tests used isolated synthetic records and did not access the user's Google account or browser ledger. GOOGLE-DRIVE-SETUP.md provides the required owner setup. Browser download requests cannot prove that a recovery file was retained; keep the downloaded JSON. Real handset installation and physical printing were not retested in this update.

User-requested karpathy-guidelines was installed and applied: focused changes, explicit manual-backup scope, no backend/cloud-account expansion, and verifiable preservation checks.
