const {test}=require('node:test');
const assert=require('node:assert/strict');
const C=require('../core');

function setup(key='2026-01'){
  const state=C.initial(),month=C.month(key),tenant=Object.assign(C.tenant(1),{id:'tenant-a',name:'Flat A',curr:100});
  month.tenants=[tenant];state.active=key;state.months={[key]:month};return {state,month,tenant};
}
function withHistory(values){
  const {state}=setup();state.months={};
  for(const [key,units]of Object.entries(values)){
    const month=C.month(key);month.tenants=[Object.assign(C.tenant(1),{id:'tenant-a',curr:units})];state.months[key]=month;
  }
  state.active=Object.keys(values).sort().at(-1);return state;
}

test('carry records provenance without changing original monthly records',()=>{
  const {state,month,tenant}=setup();tenant.payments=[{id:'payment-a',amount:200,date:'2026-01-20'}];
  const old=JSON.stringify(month);C.carry(state);const copied=state.months['2026-02'].tenants[0];
  assert.deepEqual(copied.carrySnapshot,{sourceKey:'2026-01',sourceTenantId:'tenant-a',sourceBalance:1000});
  assert.equal(copied.arrears,1000);assert.equal(JSON.stringify(month),old);assert.deepEqual(C.carryIssues(state),[]);
});
test('older month payment change flags later opening arrears; review acknowledges without rewriting',()=>{
  const {state,month,tenant}=setup();C.carry(state);const copied=state.months['2026-02'].tenants[0];
  state.months['2026-02'].finalizedAt='2026-02-28';tenant.payments.push({id:'payment-a',amount:300,date:'2026-01-20'});
  const issue=C.carryIssues(state,'2026-02')[0];assert.equal(issue.reason,'source-balance-changed');assert.equal(issue.opening,1200);assert.equal(issue.expected,900);assert.equal(issue.baseline,1200);assert.equal(issue.inferred,false);
  const total=C.bill(copied,state.months['2026-02']).total,source=JSON.stringify(month);C.reviewCarry(state,'2026-02','tenant-a');
  assert.equal(copied.arrears,1200);assert.equal(C.bill(copied,state.months['2026-02']).total,total);assert.equal(state.months['2026-02'].finalizedAt,'2026-02-28');assert.equal(JSON.stringify(month),source);assert.deepEqual(C.carryIssues(state),[]);
  tenant.payments.push({id:'payment-b',amount:100,date:'2026-01-21'});assert.equal(C.carryIssues(state)[0].baseline,900);assert.equal(C.carryIssues(state)[0].expected,800);
});
test('intentional opening-arrears edits do not trigger new provenance warnings',()=>{
  const {state}=setup();C.carry(state);state.months['2026-02'].tenants[0].arrears=1400;assert.deepEqual(C.carryIssues(state),[]);
});
test('legacy carried months infer baseline and review creates provenance only explicitly',()=>{
  const {state,tenant}=setup();C.carry(state);const copied=state.months['2026-02'].tenants[0];delete copied.carrySnapshot;
  assert.deepEqual(C.carryIssues(state),[]);assert.equal(copied.carrySnapshot,undefined);
  tenant.payments.push({id:'payment-a',amount:300,date:'2026-01-20'});const issue=C.carryIssues(state)[0];assert.equal(issue.inferred,true);assert.equal(issue.expected,900);assert.equal(copied.carrySnapshot,undefined);
  C.reviewCarry(state,'2026-02','tenant-a');assert.equal(copied.carrySnapshot.sourceBalance,900);assert.equal(copied.arrears,1200);assert.deepEqual(C.carryIssues(state),[]);
});
test('missing source months or tenants are explicit unresolved issues',()=>{
  const {state,month}=setup();C.carry(state);month.tenants=[];
  let issue=C.carryIssues(state)[0];assert.equal(issue.reason,'source-tenant-missing');assert.equal(issue.expected,null);assert.equal(issue.sourceBalance,null);assert.throws(()=>C.reviewCarry(state,'2026-02','tenant-a'),/carry-source-missing/);
  delete state.months['2026-01'];issue=C.carryIssues(state)[0];assert.equal(issue.reason,'source-month-missing');assert.throws(()=>C.reviewCarry(state,'2026-02','tenant-a'),/carry-source-missing/);assert.deepEqual(C.carryIssues(state,'1900-01'),[]);
});
test('invalid source readings cannot be acknowledged; changed source credit is visible',()=>{
  const {state,tenant}=setup();C.carry(state);tenant.curr=-1;
  assert.equal(C.carryIssues(state)[0].reason,'source-reading-invalid');assert.equal(C.carryIssues(state)[0].expected,null);assert.throws(()=>C.reviewCarry(state,'2026-02','tenant-a'),/reading/);
  tenant.curr=100;tenant.payments=[{id:'payment-a',amount:1300,date:'2026-01-20'}];const issue=C.carryIssues(state)[0];assert.equal(issue.reason,'source-credit');assert.equal(issue.sourceBalance,-100);assert.equal(issue.expected,0);
  C.reviewCarry(state,'2026-02','tenant-a');assert.deepEqual(C.carryIssues(state),[]);assert.equal(state.months['2026-02'].tenants[0].arrears,1200);
  tenant.payments[0].amount=1350;assert.equal(C.carryIssues(state)[0].sourceBalance,-150);
});
test('only directly changed carry sources warn; no silent propagation to future months',()=>{
  const {state,tenant}=setup();C.carry(state);C.carry(state);tenant.payments=[{id:'payment-a',amount:200,date:'2026-01-20'}];
  const issues=C.carryIssues(state);assert.deepEqual(issues.map(i=>i.targetKey),['2026-02']);assert.equal(state.months['2026-03'].tenants[0].arrears,1200);
});
test('account history is chronological and matches stable IDs, not names',()=>{
  const state=withHistory({'2026-03':120,'2026-01':80,'2026-02':100});state.months['2026-01'].tenants[0].name='Previous name';state.months['2026-02'].tenants.push(Object.assign(C.tenant(2),{id:'other-id',name:state.months['2026-02'].tenants[0].name,curr:500}));
  const rows=C.accountHistory(state,'tenant-a');assert.deepEqual(rows.map(r=>r.key),['2026-01','2026-02','2026-03']);assert.deepEqual(rows.map(r=>r.bill.units),[80,100,120]);assert.equal(rows[0].tenant.name,'Previous name');assert.deepEqual(C.accountHistory(state,'missing'),[]);
});
test('usage alert requires doubling and at least 50 extra units',()=>{
  let state=withHistory({'2026-01':100,'2026-02':200});assert.deepEqual(C.usageAlert(state,'2026-02','tenant-a'),{current:200,average:100,months:1,ratio:2,keys:['2026-01']});
  state.months['2026-02'].tenants[0].curr=199;assert.equal(C.usageAlert(state,'2026-02','tenant-a'),null);
  state=withHistory({'2026-01':20,'2026-02':69});assert.equal(C.usageAlert(state,'2026-02','tenant-a'),null);state.months['2026-02'].tenants[0].curr=70;assert.equal(C.usageAlert(state,'2026-02','tenant-a').current,70);
});
test('usage baseline uses latest three valid positive months and skips missing/invalid/zero readings',()=>{
  const state=withHistory({'2026-01':1000,'2026-02':50,'2026-03':0,'2026-04':50,'2026-05':-1,'2026-06':50,'2026-07':100});
  const alert=C.usageAlert(state,'2026-07','tenant-a');assert.equal(alert.average,50);assert.equal(alert.months,3);assert.deepEqual(alert.keys,['2026-02','2026-04','2026-06']);
  assert.equal(C.usageAlert(state,'2026-01','tenant-a'),null);assert.equal(C.usageAlert(state,'2026-03','tenant-a'),null);assert.equal(C.usageAlert(state,'2026-05','tenant-a'),null);assert.equal(C.usageAlert(state,'2026-07','missing'),null);
});
test('backup validation accepts legacy/provenance and rejects unsafe optional metadata',()=>{
  const {state}=setup();assert.doesNotThrow(()=>C.validate(state));C.carry(state);assert.doesNotThrow(()=>C.validate(JSON.parse(JSON.stringify(state))));C.reviewCarry(state,'2026-02','tenant-a');assert.doesNotThrow(()=>C.validate(state));
  const copied=state.months['2026-02'].tenants[0];copied.carrySnapshot.sourceBalance='1200';assert.throws(()=>C.validate(state),/backup/);copied.carrySnapshot.sourceBalance=1200;
  copied.carrySnapshot.sourceKey='2026-03';assert.throws(()=>C.validate(state),/backup/);copied.carrySnapshot.sourceKey='2026-01';copied.carrySnapshot.sourceTenantId='<bad>';assert.throws(()=>C.validate(state),/backup/);copied.carrySnapshot.sourceTenantId='tenant-a';copied.carrySnapshot.reviewedAt={};assert.throws(()=>C.validate(state),/backup/);
});
test('backup reminder metadata is optional and validates ISO timestamps/months',()=>{
  const {state}=setup();assert.doesNotThrow(()=>C.validate(state));state.lastBackupAt='2026-11-11T05:00:00.000Z';state.backupPendingSince='2026-11-10T11:00:00+06:00';state.lastBackupMonth='2026-11';assert.doesNotThrow(()=>C.validate(state));
  state.lastBackupAt={};assert.throws(()=>C.validate(state),/backup/);delete state.lastBackupAt;state.lastBackupMonth='2026-13';assert.throws(()=>C.validate(state),/backup/);delete state.lastBackupMonth;state.backupPendingSince='not-a-date';assert.throws(()=>C.validate(state),/backup/);
});

test('backup destination remains optional for legacy records and accepts only supported destinations',()=>{
  const {state}=setup();assert.doesNotThrow(()=>C.validate(state));
  for(const destination of ['download','google-drive']){state.lastBackupDestination=destination;assert.doesNotThrow(()=>C.validate(JSON.parse(JSON.stringify(state))));}
  for(const destination of ['',null,{},true,'drive','https://example.com']){state.lastBackupDestination=destination;assert.throws(()=>C.validate(state),/backup/);}
  delete state.lastBackupDestination;assert.doesNotThrow(()=>C.validate(state));
});

test('message language defaults to English and survives backup round trips independently of app language',()=>{
  const state=C.initial();assert.equal(state.messageLanguage,'en');
  for(const language of ['en','bn']){
    state.lang=language==='en'?'bn':'en';state.messageLanguage=language;
    const restored=C.validate(JSON.parse(JSON.stringify(state)));
    assert.equal(restored.messageLanguage,language);assert.notEqual(restored.messageLanguage,restored.lang);
  }
});

test('legacy backups may omit message language without validation adding a default',()=>{
  const state=C.initial();state.lang='bn';delete state.messageLanguage;
  const before=JSON.stringify(state),restored=C.validate(state);
  assert.equal(restored,state);assert.equal(Object.hasOwn(restored,'messageLanguage'),false);assert.equal(JSON.stringify(state),before);
});

test('backup validation rejects unsupported or incorrectly typed message language',()=>{
  const state=C.initial();
  for(const language of ['',null,{},[],true,0,'BN','auto','en-US']){
    state.messageLanguage=language;assert.throws(()=>C.validate(state),/backup/);
  }
});
