# Monthly billing workspace

Mode: Operate.
THESIS: Complete monthly readings, bills and collections with confidence.
OWN-WORLD: Original electric meter/building logo, familiar blue primary actions, rounded white working sheets.
STORY: Enter readings, review the main bill, issue statements/slips, collect payments, carry forward.
FIRST VIEWPORT: Two-tab navigation, billing month and next-month action, grouped financial metrics and the reading ledger.
FORM: User-requested Apple-inspired redesign; system typography, restrained color, immediate reduced-motion-aware press feedback and native dialogs. No raster comp or quality-bar card was supplied.

The PDF reference controls the paper layout only. English/Bangla output selection is independent of interface language.
